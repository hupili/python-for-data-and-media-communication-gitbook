# A demo helloworld example under the assets folder

print('Hello World')
